package com.vaccination.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CovidVaccinationProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
